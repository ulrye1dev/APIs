Youtube API Search
==================

[Demo Site](http://somecallmejosh.github.io/youtube-api-search)

- [ ] Capture User Search String
- [ ] Display thumbnail images of videos that match the search
- [ ] Link to video

## To Get Youtube API Key
- [x] Log into the Google Developer's Console. You need a Google account.
- [x] Click the Create Project button.
- [x] Fill out the form, picking any project name you want.
- [x] Click 'API's & auth' and then credentials on the left side.
- [x] Under "Public API Access" click Add Credentials.
- [x] You should see a popup. Click browser key.
- [x] On "Create Browser Key and Configure Allowed Referers" you can leave the box blank and click Create. You will see your API key on the right.