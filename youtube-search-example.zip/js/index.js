$.ajax({
  dataType: "json",
  url: 
    'https://www.googleapis.com/youtube/v3/search'+
    '?part=snippet'+
    '&maxResults=10'+
    '&order=viewCount'+
    '&q=밴드코로나'+
    '&type=video'+
    '&videoDefinition=high'+
    '&key=AIzaSyChPQ7wyJdU2QcGXf3DJqeqAy4uHhdRdLA'
}).done(function(data){
	/* Initial */
	var tag = document.createElement('script');
	tag.src = "https://www.youtube.com/iframe_api";
	var firstScriptTag = document.getElementsByTagName('script')[0];
	firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

	var player;
	
	onYouTubeIframeAPIReady = function(event){
		player = new YT.Player('youtube-player', {
			videoId: data.items[0].id.videoId
		});
	}
	
	$('#video-title').text(data.items[0].snippet.title);
	$('#youtube-list').mCustomScrollbar({theme: 'dark'});
	
	/* List */
	var length = data.items.length;
	
	for(var i=0; i<length; i++){
		var item = data.items[i];
		var videoThumb = item.snippet.thumbnails.medium.url;
		var videoTitle = item.snippet.title;
		
		li = '<li>'+					
							'<img src="'+videoThumb+'" class="thumb">'+
							'<p class="title"><span class="outer"><span class="inner">'+videoTitle+'</span></span></p>'+
					'</li>';
		$('ul').append(li);
	}
	
 });