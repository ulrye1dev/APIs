geo-search-tool
==================

A web app that uses the YouTube Data API v3's search functionality to find videos tagged with geo-coordinates.

This is not an official Google product.

View the live demo at http://youtube.github.io/geo-search-tool/search.html
